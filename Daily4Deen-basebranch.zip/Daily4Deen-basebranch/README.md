# Daily4Deen
An Webapp for teaching islamic studies
