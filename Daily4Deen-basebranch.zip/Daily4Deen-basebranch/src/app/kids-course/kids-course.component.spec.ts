import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KidsCourseComponent } from './kids-course.component';

describe('KidsCourseComponent', () => {
  let component: KidsCourseComponent;
  let fixture: ComponentFixture<KidsCourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KidsCourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KidsCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
