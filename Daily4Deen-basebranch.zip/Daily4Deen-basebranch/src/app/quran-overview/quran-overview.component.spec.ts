import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuranOverviewComponent } from './quran-overview.component';

describe('QuranOverviewComponent', () => {
  let component: QuranOverviewComponent;
  let fixture: ComponentFixture<QuranOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuranOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuranOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
