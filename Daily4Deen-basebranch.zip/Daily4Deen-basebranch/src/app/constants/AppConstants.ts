export const LOADER_SHOW: string = 'show';
export const LOADER_HIDE: string = 'hide';