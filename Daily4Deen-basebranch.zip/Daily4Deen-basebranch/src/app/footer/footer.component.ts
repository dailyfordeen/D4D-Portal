import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { NotificationsService, NotificationType } from 'angular2-notifications';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  news: FormGroup;
  submitted: boolean;

  constructor(private  formBuilder:FormBuilder, private _notifications: NotificationsService,) { }

  ngOnInit(): void {
    window.scroll(0,0);
    this.news = this.formBuilder.group({
      email: ['', Validators.required],
       
    })
  }
    
   get f() { return this.news.controls; }

   onSubmit() {
     this.submitted = true;
 
     
     if (this.news.invalid) {
       this._notifications.create('Error!', 'Please provide valid details..', NotificationType.Error, {
         timeOut: 1000,
       })
       return;
     }
     else {
       
     }
 
   }
 
   onReset() {
    
     this.news.reset();
   }

}
