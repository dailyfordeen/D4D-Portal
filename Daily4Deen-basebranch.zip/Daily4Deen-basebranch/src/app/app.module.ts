import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; 
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BannerComponent } from './banner/banner.component';
import { LoginComponent } from './login/login.component';
import { IslamicStudiesComponent } from './islamic-studies/islamic-studies.component';
import { QuranTbrComponent } from './quran-tbr/quran-tbr.component';
import { QuranOverviewComponent } from './quran-overview/quran-overview.component';
import { KidsCourseComponent } from './kids-course/kids-course.component';
import { QuranTComponent } from './quran-t/quran-t.component';
import { OurPublicationComponent } from './our-publication/our-publication.component';
import { FreeResourcesComponent } from './free-resources/free-resources.component';
import { MiscComponent } from './misc/misc.component';
import { RegisterComponent } from './register/register.component';
import { CourseComponent } from './course/course.component';
import { AsmaUlComponent } from './asma-ul/asma-ul.component';
import { MenuService } from './menu.service';
import { ContactComponent } from './contact/contact.component';
import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { environment } from '../environments/environment';
import { AngularFirestoreModule } from '@angular/fire/firestore';

import { SimpleNotificationsModule } from 'angular2-notifications';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';
import { CpanelComponent } from './cpanel/cpanel.component';
import { SafePipeModule } from 'safe-pipe';
import { GenericMenuComponent } from './generic-menu/generic-menu.component';
import { NewsFeedComponent } from './news-feed/news-feed.component';
import { SettingsComponent } from './settings/settings.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BannerComponent,
    LoginComponent,
    IslamicStudiesComponent,
    QuranTbrComponent,
    QuranOverviewComponent,
    KidsCourseComponent,
    QuranTComponent,
    OurPublicationComponent,
    FreeResourcesComponent,
    MiscComponent,
    RegisterComponent,
    CourseComponent,
    AsmaUlComponent,
    ContactComponent,
    CpanelComponent,
    GenericMenuComponent,
    NewsFeedComponent,
    SettingsComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFirestoreModule,
    AngularFireDatabaseModule,
    ReactiveFormsModule ,
    FormsModule,
    BrowserAnimationsModule,
    SimpleNotificationsModule.forRoot(),
    SafePipeModule,
    NgxLoadingModule.forRoot({  animationType: ngxLoadingAnimationTypes.doubleBounce,
      backdropBackgroundColour: 'rgba(0,0,0,0.1)', 
      backdropBorderRadius: '4px',
      primaryColour: '#ffffff', 
      secondaryColour: '#ffffff', 
      tertiaryColour: '#ffffff'})
     
  ],
  providers: [MenuService],
  bootstrap: [AppComponent]
})
export class AppModule { }
