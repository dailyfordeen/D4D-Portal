import { Component, OnInit } from '@angular/core';
import { FileUploadService } from '../file-upload.service';
import { AuthService } from '../auth.service';
import * as moment from 'moment';
import { FirebaseService } from '../firebase.service';
import { NotificationsService, NotificationType } from 'angular2-notifications';
import { AngularFireStorage } from '@angular/fire/storage';
import { finalize } from 'rxjs/operators';
import { LOADER_SHOW, LOADER_HIDE } from '../constants/AppConstants';
import * as _ from "lodash";
import { FileUpload } from '../cpanel/cpanel.component';

@Component({
  selector: 'app-news-feed',
  templateUrl: './news-feed.component.html',
  styleUrls: ['./news-feed.component.scss']
})
export class NewsFeedComponent implements OnInit {
  selectedFilesImg: any;
  basePath: string;
  currentFileUpload: FileUpload;
  lessonPreviewImage: any;
  lessonImg:any;
  postText:string="";
  postList:any=[];
  constructor(private fileUploadService: FileUploadService, private fireBaseService: FirebaseService,
    private authService: AuthService, private _notifications: NotificationsService, private storage: AngularFireStorage, private storage2: AngularFireStorage) { }

  ngOnInit(): void {
    this.postText='';
    this.postList=[];
    this.readAllPost();
  }

  selectFile(event, type): void {
    if (type == 0) {
      this.selectedFilesImg = event.target.files;
    }
  }
  upload(): void {
    this.authService.showHideLoading(LOADER_SHOW);
    const lessonImg = this.selectedFilesImg.item(0);
    
    const customMetadata = { app: 'Daily4DeenApp' };
    this.basePath = '/uploads';
    this.currentFileUpload = new FileUpload(lessonImg, null);
    let filePath = `${this.basePath}/${lessonImg.name}`;
    let storageRef = this.storage.ref(filePath);
    let uploadTask = this.storage.upload(filePath, lessonImg, { customMetadata });
     
    uploadTask.snapshotChanges().pipe(
      finalize(() => {
        storageRef.getDownloadURL().subscribe(downloadURL => {
          this.lessonPreviewImage = downloadURL;
          if (this.lessonPreviewImage != null) {
            this.createPost(this.lessonPreviewImage);
          }
        });
      })
    ).subscribe();



  }
  createPost(lessonPreviewImage: any) {
     let obj={};
     obj['postImagePath']=lessonPreviewImage;
     obj['postText']=this.postText;
     obj['uploadedBy']=this.authService.getLoggedinUser();
     obj['uploadedOn']=moment(new Date())['_d'].toString();
     this.fireBaseService.savePost(obj).then(resp => {
      if (resp != null) {
        this.authService.showHideLoading(LOADER_HIDE);
        this._notifications.create('Success!', 'Saved Successfully ..', NotificationType.Success, {
          timeOut: 500,
        })
        this.lessonImg='';
        this.postText='';
        this.readAllPost();
      } else {
        this.authService.showHideLoading(LOADER_HIDE);
        this._notifications.create('Error!', 'Something went wrong ..', NotificationType.Error, {
          timeOut: 500,
        });
      }
    })
      .catch(error => {
        this.authService.showHideLoading(LOADER_HIDE);
        console.log(error);
      });
  }
  ago(time) {
    let difference = moment(moment(time)['_d']).diff(moment());
    return moment.duration(difference).humanize();
  }
  readAllPost() {
    this.fireBaseService.readPost().subscribe(data => {
      this.authService.showHideLoading(LOADER_SHOW);
      setTimeout(() => {
        this.authService.showHideLoading(LOADER_HIDE);
      }, 1000);
      this.postList = data.map(e => {
        return {
          id: e.payload.doc.id,
          postText: e.payload.doc.data()['postText'],
          postImagePath: e.payload.doc.data()['postImagePath'],
          uploadedBy: e.payload.doc.data()['uploadedBy'],
          uploadedOn: this.ago(e.payload.doc.data()['uploadedOn']),
      
        };
      })
      this.postList=_.orderBy(this.postList, ['uploadedOn'], ['desc']);
      

    });
  }
}
