import { Injectable } from '@angular/core';

@Injectable()
export class MenuService {
  constructor() {}

  getMenu(): Array<any> {
    const menu = [
      { name: 'Home', path: './home', children: [] },
      { name: 'Login', path: './login', children: [] },
      { name: 'Register', path: './register', children: [] },
      { name: 'Free Resource', path: './freeResource', children: [] },
      { name: 'Islamic-Studies', path: './islamicStudies', children: [] },
      { name: 'Quran-Tadabbur', path: './quran-tbr', children: [] },
      { name: 'Quran Ts', path: './quran-t', children: [] },
      { name: 'Kids Course', path: './kids-course', children: [] },
      { name: 'Asma-ul Husna', path: './asma', children: [] },
      { name: 'Quran Overview', path: './quran-overview', children: [] },
      { name: 'Our Publications', path: './publication', children: [] },
      { name: 'Settings', path: './settings', children: [] },
      { name: 'Added Course', path: './genericMenu', children: [] },
      { name: 'Misc', path: './misc', children: [] },
      { name: 'News Feed', path: './news', children: [] },
      {name:'Contact',path:'./contact',children:[]},
      {name:'Cpanel',path:'./cpanel',children:[]}
      
    ];

    return menu;
  }
}
