import { Injectable } from '@angular/core';

import { AngularFirestore } from '@angular/fire/firestore';
import { Subject } from 'rxjs';
import { AngularFireStorageModule, AngularFireStorage, AngularFireStorageReference, AngularFireUploadTask } from '@angular/fire/storage';
import { map } from 'rxjs/operators';
import * as moment from 'moment';

import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
@Injectable({
  providedIn: 'root'
})
export class FirebaseService {

  constructor(
    private firestore: AngularFirestore
  ) { }


  createNewUser(record) {
    return this.firestore.collection('user').add(record);
  }
  saveLesson(record) {
    return this.firestore.collection('lesson').add(record);
  }
  readCustomMenu() {
    return this.firestore.collection('customMenu').snapshotChanges();

  }
  saveCustomMenu(record) {
    return this.firestore.collection('customMenu').add(record);
  }
  savePost(obj){
    return this.firestore.collection('posts').add(obj);
  }
  readUsers() {
    return this.firestore.collection('user').snapshotChanges();
  }
  readPost() {
    return this.firestore.collection('posts').snapshotChanges();
  }
  readLesson() {
    return this.firestore.collection('lesson').snapshotChanges();
  }

  updateUser(recordID, record) {
    this.firestore.doc('user/' + recordID).update(record);
  }

  deleteUser(record_id) {
    this.firestore.doc('user/' + record_id).delete();
  }
  deleteLesson(record_id) {
    this.firestore.doc('lesson/' + record_id).delete();
  }
  deleteMenu(id) {
    this.firestore.doc('customMenu/' + id).delete();

  }
  readLessonWithCategory(course) {
    return this.firestore.collection('lesson', ref =>
      ref.where('course', '==', course)
    ).snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data: any = a.payload.doc.data();
        const id = a.payload.doc.id;
        return { id, ...data };
      }))
    );
  }
  getRequestDetails(userName) {

    return this.firestore.collection('user', ref =>
      ref.where('username', '==', userName)
    ).snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data: any = a.payload.doc.data();
        const id = a.payload.doc.id;
        return { id, ...data };
      }))
    );
  }
}