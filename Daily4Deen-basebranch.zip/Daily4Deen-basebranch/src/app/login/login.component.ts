import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NotificationsService, NotificationType } from 'angular2-notifications';
import { FirebaseService } from '../firebase.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { LOADER_SHOW, LOADER_HIDE } from '../constants/AppConstants';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  /**
   * 
   * @param formBuilder 
   * @param _notifications 
   * @param firebaseService 
   */
  constructor(private formBuilder: FormBuilder,
    private _notifications: NotificationsService,
    private firebaseService: FirebaseService,
    private _router: Router,
    private authService: AuthService) { }

  ngOnInit(): void {
    window.scroll(0,0);
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    })
    
  };
  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      //this.toastr.error('Error!', '');
      this._notifications.create('Error!', 'Please provide valid details..', NotificationType.Error, {
        timeOut: 1000,
      })
      return;
    }
    else {
      let loginObj = this.loginForm.value;
      this.authService.showHideLoading(LOADER_SHOW);
      this.firebaseService.getRequestDetails(loginObj['username']).subscribe((res: any) => {
        if (res != null) {
          if (res.length > 0) {
            this.authService.showHideLoading(LOADER_HIDE);
            if (res[0]['password'] == loginObj['password']) {
              this.authService.changeMessage("logged");
               
              this.authService.login(loginObj['username'], res[0]['userType']).subscribe(data => {
                this.authService.changeMessage("logged");
              });
              
              this._notifications.create('Success!', 'Welcome..', NotificationType.Success,
                {
                  timeOut: 1000,
                }
              );
            }
            this.authService.changeMessage("logged");
            this._router.navigateByUrl('/home'); 
          }else{
            this.authService.showHideLoading(LOADER_HIDE);
            this._notifications.create('Error!', 'Invalid Credentails..', NotificationType.Error,
            {
              timeOut: 1000,
            }
          );
          return;
          }
        } else {
          this._notifications.create('Error!', 'Invalid Credentails..', NotificationType.Error,
            {
              timeOut: 1000,
            }
          );
          return;
        }
      });
    }

  }

  onReset() {
    this.submitted = false;
    this.loginForm.reset();
  }
}
