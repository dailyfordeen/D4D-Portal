import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-free-resources',
  templateUrl: './free-resources.component.html',
  styleUrls: ['./free-resources.component.scss']
})
export class FreeResourcesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    window.scroll(0,0);
  }

}
