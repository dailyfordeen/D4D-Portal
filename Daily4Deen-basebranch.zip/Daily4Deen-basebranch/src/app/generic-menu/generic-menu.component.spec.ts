import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenericMenuComponent } from './generic-menu.component';

describe('GenericMenuComponent', () => {
  let component: GenericMenuComponent;
  let fixture: ComponentFixture<GenericMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenericMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
