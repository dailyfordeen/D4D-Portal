import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth.service';
import { FileUploadService } from '../file-upload.service';
import { FirebaseService } from '../firebase.service';
import { NotificationsService } from 'angular2-notifications';
import { DomSanitizer } from '@angular/platform-browser';
import { LOADER_HIDE, LOADER_SHOW } from '../constants/AppConstants';
import * as moment from 'moment';
@Component({
  selector: 'app-generic-menu',
  templateUrl: './generic-menu.component.html',
  styleUrls: ['./generic-menu.component.scss']
})
export class GenericMenuComponent implements OnInit {
  pathVariable: string;
  screenId: string;
  screenName: string;

  lessonList: any = [];
  lessonBannerImg: any;
  lessonPDFUrl: any;
  lessonDescription: any;
  lessonUploadedBy: any;
  lessonUploadedOn: any;
  lessonComments: any;
  lessonName: any;
  lessonVideo: any;
  constructor(private _Activatedroute: ActivatedRoute,
    private fireBaseService: FirebaseService, private formBuilder: FormBuilder,
    private fileUploadService: FileUploadService,
    
    private authService: AuthService,
    private _notifications: NotificationsService,
    private dom: DomSanitizer) {
  }
  sub;
 
  searchForm: FormGroup;
  showEntry:boolean=false
  ngOnInit(): void {
    window.scroll(0,0);
    this.sub = this._Activatedroute.paramMap.subscribe(params => {
      console.log(params);
      this.pathVariable = params.get('id');

      this.screenId = this.pathVariable.split("_")[0];
      this.screenName = this.pathVariable.split("_")[1];
     
      this.fireBaseService.readLessonWithCategory(this.screenId).subscribe((res: any) => {
        if (res != null) {
          if (res.length > 0) {
            this.lessonList = res;
           
            this.showLesson(this.lessonList[0]);
            this.lessonList.forEach(element => {
              if (element['uploadedOn'] != null) {
                element['uploadedOn'] = this.ago(element['uploadedOn']);
              }
            });
          }else{
            this.lessonList=[];
          }
        } 
        document.getElementById('breadCrumMenu').innerHTML=this.screenName;
      });
      this.searchForm = this.formBuilder.group({
        search: ['']
      })
    });
  
  }
  
  showLesson(lesson){
    this.authService.showHideLoading(LOADER_SHOW);
    this.lessonBannerImg=lesson['lessonImg'];
    this.lessonPDFUrl = lesson['lessonPDF'];
    this.lessonName=lesson['lessonName'];
    this.lessonDescription=lesson['lessonDesc'];
    this.lessonVideo=lesson['lessonVideo'];
    this.lessonUploadedBy=lesson['uploadedBy'];
    this.lessonUploadedOn=this.ago(lesson['uploadedOn']);
    this.lessonComments="0 Comments";
    this.showEntry=true;
    setTimeout(() => {
      this.authService.showHideLoading(LOADER_HIDE);
    }, 1000);
  }
  
   
  ago(time) {

    let difference = moment(moment(time)['_d']).diff(moment());
    return moment.duration(difference).humanize();
  }
  get f() { return this.searchForm.controls; }
  onSubmit() {

  }
 ngOnDestroy(){
  document.getElementById('breadCrumMenu').innerHTML='';
 }
}
