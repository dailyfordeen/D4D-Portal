import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MustMatch } from '../helper/must-match-helper';
import { NotificationsService, NotificationType } from 'angular2-notifications';
import { FirebaseService } from '../firebase.service';
import { Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from "lodash";
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {

 
  registartionForm: FormGroup;
  submitted = false;
  userExist: boolean = false;
  userList: any=[];
  /**
   * 
   * @param formBuilder 
   * @param _notifications 
   * @param firebaseService 
   */
  constructor(private formBuilder: FormBuilder,
    private _notifications: NotificationsService,
    private firebaseService: FirebaseService,private authService:AuthService,
    private _router: Router) { }
    /**
     * Init
     */
  ngOnInit(): void {
    window.scroll(0,0);
    this.firebaseService.readUsers().subscribe(data => {

      this.userList = data.map(e => {
        return {
          id: e.payload.doc.id,
          username: e.payload.doc.data()['username'],
          userType: e.payload.doc.data()['userType'] == 'A' ? 'Admin' : 'Student',
          address: e.payload.doc.data()['address'],
          email: e.payload.doc.data()['email'],
          password:e.payload.doc.data()['password'],
          mob: e.payload.doc.data()['mob'],
        };
      })
      console.log(this.userList);
      this.fillvalue();
    });
    
    this.registartionForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      cpassword: ['', Validators.required],
      mob: ['', Validators.required],
      email: ['', Validators.required],
      address: [''],
    });

  

  }
  fillvalue() {
    let userObj=this.userList.filter(x=>x.username==this.authService.getLoggedinUser());

    if(userObj!=null){
      userObj=userObj[0];
      this.registartionForm = this.formBuilder.group({
        id:[userObj['id']],
        username: [userObj['username'], Validators.required],
        password: [userObj['password'], Validators.required],
        cpassword: [userObj['password'], Validators.required],
        mob: [userObj['mob'], Validators.required],
        email: [userObj['email'], Validators.required],
        address: [userObj['address']],
      });
    }
   
  }
  
  /**
   * Get Fields
   */
  get f() { return this.registartionForm.controls; }
  /**
   * Submit
   */
  onSubmit() {
    this.submitted = true;

    if (this.registartionForm.invalid) {
     
      return;
    } else {
      let regObj = this.registartionForm.value;
      if (regObj['cpassword'] != regObj['password']) {
        this._notifications.create('Error!', 'Password mismatch..', NotificationType.Error)
        return;
      }
      else if (isNaN(regObj['mob'])) {
        this._notifications.create('Error!', 'Provide valid Mobile number ..', NotificationType.Error)
        return;
      }

      else {
         
          this.firebaseService.updateUser(regObj['id'],regObj);
          this._notifications.create('Success!', 'User Details Updated ..', NotificationType.Success, {
            timeOut: 1000,
          })
        


      }
      

    }


  }


  onReset() {
    this.submitted = false;
    this.registartionForm.reset();
  }

}
