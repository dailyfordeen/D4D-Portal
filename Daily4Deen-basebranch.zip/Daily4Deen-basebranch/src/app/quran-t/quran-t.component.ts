 import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AuthService } from '../auth.service';
import { FileUploadService } from '../file-upload.service';
import { NotificationsService } from 'angular2-notifications';
import * as moment from 'moment';
import { FirebaseService } from '../firebase.service';
import { DomSanitizer } from '@angular/platform-browser';
import { LOADER_HIDE, LOADER_SHOW } from '../constants/AppConstants';

@Component({
  selector: 'app-quran-t',
  templateUrl: './quran-t.component.html',
  styleUrls: ['./quran-t.component.scss']
})
export class QuranTComponent implements OnInit {
  lessonList: any = [];
  lessonBannerImg: any;
  lessonPDFUrl: any;
  lessonDescription: any;
  lessonUploadedBy: any;
  lessonUploadedOn: any;
  lessonComments: any;
  lessonName: any;
  lessonVideo: any;

  /**
   * constructor
   * @param formBuilder 
   * @param fileUploadService 
   * @param fireBaseService 
   * @param authService 
   * @param _notifications 
   * @param storage 
   */
  constructor(private formBuilder: FormBuilder,
    private fileUploadService: FileUploadService,
    private fireBaseService: FirebaseService,
    private authService: AuthService,
    private _notifications: NotificationsService,
    private dom:DomSanitizer
  ) { }
  searchForm: FormGroup;
  showEntry:boolean=false
  ngOnInit(): void {
    window.scroll(0,0);
    this.fireBaseService.readLessonWithCategory("2").subscribe((res: any) => {
      if (res != null) {
        if (res.length > 0) {
          this.lessonList = res;
          this.showLesson(this.lessonList[0]);
          this.lessonList.forEach(element => {
            if (element['uploadedOn'] != null) {
              element['uploadedOn'] = this.ago(element['uploadedOn']);
            }
          });
        }
      }
    });
    this.searchForm = this.formBuilder.group({
      search: ['']
    })
  }
  
  showLesson(lesson){
    this.authService.showHideLoading(LOADER_SHOW);
    this.lessonBannerImg=lesson['lessonImg'];
    this.lessonPDFUrl = lesson['lessonPDF'];
    this.lessonName=lesson['lessonName'];
    this.lessonDescription=lesson['lessonDesc'];
    this.lessonVideo=lesson['lessonVideo'];
    this.lessonUploadedBy=lesson['uploadedBy'];
    this.lessonUploadedOn=this.ago(lesson['uploadedOn']);
    this.lessonComments="0 Comments";
    this.showEntry=true;
    setTimeout(() => {
      this.authService.showHideLoading(LOADER_HIDE);
    }, 1000);
  }
  
   
  ago(time) {

    let difference = moment(moment(time)['_d']).diff(moment());
    return moment.duration(difference).humanize();
  }
  get f() { return this.searchForm.controls; }
  onSubmit() {

  }

  
}
