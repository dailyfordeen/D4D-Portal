import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuranTComponent } from './quran-t.component';

describe('QuranTComponent', () => {
  let component: QuranTComponent;
  let fixture: ComponentFixture<QuranTComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuranTComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuranTComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
