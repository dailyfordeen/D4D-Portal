import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.scss']
})
export class BannerComponent implements OnInit {
  mobile: boolean;
  suraObjEn: any={};
  suraObjFr: any={};
  ayath: number;

  constructor() {
    this.ayath=Math.floor(Math.random() * 6326);
    const Http = new XMLHttpRequest();
    const url = 'https://api.alquran.cloud/v1/ayah/'+this.ayath+'/en.asad';
    Http.open("GET", url);
    Http.send();

    Http.onreadystatechange = (e) => {
      let innerTxtEn = Http.responseText;
      this.suraObjEn={}
      this.suraObjEn = JSON.parse(innerTxtEn);
      this.suraObjEn['data']['surah']['name']=decodeURIComponent(JSON.parse(this.suraObjEn['data']['surah']['name']));
      
       
    }
    const HttpFr = new XMLHttpRequest();
    const urlFr = 'https://api.alquran.cloud/v1/ayah/'+this.ayath+'/ar.asad';
    HttpFr.open("GET", urlFr);
    HttpFr.send();

    HttpFr.onreadystatechange = (e) => {
      let innerTxtFr = HttpFr.responseText;
      console.log(innerTxtFr);
      this.suraObjFr={}
      this.suraObjFr = JSON.parse(innerTxtFr)
      this.suraObjFr['data']['surah']['name']=decodeURIComponent(JSON.parse(this.suraObjFr['data']['surah']['name']));
       
    }
  }

  ngOnInit(): void {
    window.scroll(0,0);
    if (window.screen.width === 360) { // 768px portrait
      this.mobile = true;
    }
  }

}
