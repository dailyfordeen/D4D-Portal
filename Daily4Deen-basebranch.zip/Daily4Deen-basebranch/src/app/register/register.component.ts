import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MustMatch } from '../helper/must-match-helper';
import { NotificationsService, NotificationType } from 'angular2-notifications';
import { FirebaseService } from '../firebase.service';
import { Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from "lodash";
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  registartionForm: FormGroup;
  submitted = false;
  userExist: boolean = false;
  userList: any;
  /**
   * 
   * @param formBuilder 
   * @param _notifications 
   * @param firebaseService 
   */
  constructor(private formBuilder: FormBuilder,
    private _notifications: NotificationsService,
    private firebaseService: FirebaseService,
    private _router: Router) { }
    /**
     * Init
     */
  ngOnInit(): void {
    window.scroll(0,0);
    this.firebaseService.readUsers().subscribe(data => {

      this.userList = data.map(e => {
        return {
          username: e.payload.doc.data()['username']
        };
      })
      console.log(this.userList);
    });

    this.registartionForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      cpassword: ['', Validators.required],
      mob: ['', Validators.required],
      email: ['', Validators.required],
      address: [''],
    });

  }
  /**
   * Get Fields
   */
  get f() { return this.registartionForm.controls; }
  /**
   * Submit
   */
  onSubmit() {
    this.submitted = true;

    if (this.registartionForm.invalid) {
     
      return;
    } else {
      let regObj = this.registartionForm.value;
      if (regObj['cpassword'] != regObj['password']) {
        this._notifications.create('Error!', 'Password mismatch..', NotificationType.Error)
        return;
      }
      else if (isNaN(regObj['mob'])) {
        this._notifications.create('Error!', 'Provide valid Mobile number ..', NotificationType.Error)
        return;
      }

      else {
        let userList = _.filter(this.userList, function (o) { return o.username === regObj['username'] });
        if (userList != null && userList.length > 0) {
          this._notifications.create('Error!', 'Username Already Exist ..', NotificationType.Error, {
            timeOut: 1000,
          })
        } else {
          regObj['userType'] = 'V';
          regObj['createdOn'] = moment(new Date())['_d'].toString();
          this.firebaseService.createNewUser(regObj).then(resp => {
            if (resp != null) {
              this._notifications.create('Success!', 'Registered Successfully ..', NotificationType.Success)
              this._router.navigateByUrl('/login');
            } else {
              this._notifications.create('Error!', 'Something went wrong ..', NotificationType.Error);
            }

          })
            .catch(error => {
              console.log(error);
            });
        }


      }
      

    }


  }


  onReset() {
    this.submitted = false;
    this.registartionForm.reset();
  }

}
