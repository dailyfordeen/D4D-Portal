import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router, NavigationEnd } from '@angular/router';
import { FirebaseService } from '../firebase.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  loggedInUser: string = '';
  adminUser: string;
  menuList = [];
  @ViewChild('myDiv') myDiv: ElementRef<HTMLElement>;
  constructor(private firebaseService: FirebaseService, private authService: AuthService, private _router: Router,) { }

  showMeDynamic(menu){
    console.log(menu);
    this._router.navigateByUrl('/genericMenu/'+menu['menuId']+'_'+menu['menuName']);
  }
  ngOnInit(): void {
    window.scroll(0, 0);
    this.firebaseService.readCustomMenu().subscribe(data => {

      this.menuList = data.map(e => {
        return {
          menuName: e.payload.doc.data()['menuName'],
          menuId: e.payload.doc.data()['menuId']
        };
      })
      console.log(this.menuList);
    });
    this._router.events.forEach((event) => {
      if (event instanceof NavigationEnd) {
        if (document.querySelector('.navbar-mobile') != null) {
          this.myDiv.nativeElement.click();
        }

      }

    });
    this.authService.currentMessage.subscribe((message) => {
      if (message === "logged" || message == "message") {
        if (this.authService.isUserLoggedIn()) {
          this.loggedInUser = this.authService.getLoggedinUser();
          this.adminUser = this.authService.getLoggedinUserType();
        } else {
          this.loggedInUser = '';
        }
      } else if (message === "logout") {
        this.loggedInUser = '';
      }
    });


  }
  logout() {
    this.authService.logoutUser();
    this.authService.changeMessage("logout");
    this._router.navigateByUrl('/login');
  }

  mobileView() {
    this.select('#navbar').classList.toggle('navbar-mobile')

  }


  select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }
  subMenu(e) {
    if (this.select('#navbar').classList.contains('navbar-mobile')) {
      e.preventDefault()
      e.target.parentElement.children[1].classList.toggle('dropdown-active');

    }
  }

}
