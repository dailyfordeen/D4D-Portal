import { Injectable } from '@angular/core';
import { Observable, Observer, BehaviorSubject } from 'rxjs';


import { of } from 'rxjs';
import { LOADER_HIDE } from './constants/AppConstants';

@Injectable({
  providedIn: 'root'
})

export class AuthService {
  private isloggedIn: boolean;
  private userName: string;
  private messageSource = new BehaviorSubject("message");
  private loaderMessageSource = new BehaviorSubject("hide");
  currentMessage = this.messageSource.asObservable();
  loaderMessage = this.loaderMessageSource.asObservable();


  showHideLoading(msg: string) {
    this.loaderMessageSource.next(msg);
  }
  changeMessage(message: string) {
    this.messageSource.next(message);

  }
  constructor() {
    this.isloggedIn = false;
  }

  login(username: string, userType: string) {
    this.isloggedIn = true;
    this.userName = username;
    localStorage.setItem('LOGGED_IN_USER', this.userName);
    localStorage.setItem('LOGGED_IN_USER_TYPE', userType);
    return of(this.isloggedIn);
  }
  getLoggedinUser(): string {
    return localStorage.getItem('LOGGED_IN_USER');
  }
  getLoggedinUserType(): string {
    return localStorage.getItem('LOGGED_IN_USER_TYPE');
  }
  isUserLoggedIn(): boolean {
    if (localStorage.getItem('LOGGED_IN_USER') != null && localStorage.getItem('LOGGED_IN_USER') != 'null') {
      this.isloggedIn = true;
    } else {
      this.isloggedIn = false;
    }

    return this.isloggedIn;
  }

  isAdminUser(): boolean {
    if (this.userName == 'Admin') {
      return true;
    }
    return false;
  }

  logoutUser(): void {
    this.isloggedIn = false;
    localStorage.setItem('LOGGED_IN_USER', null);
    localStorage.setItem('LOGGED_IN_USER_TYPE', null);
  }
}
