import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-publication',
  templateUrl: './our-publication.component.html',
  styleUrls: ['./our-publication.component.scss']
})
export class OurPublicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    window.scroll(0,0);
  }

}
