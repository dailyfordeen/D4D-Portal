import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OurPublicationComponent } from './our-publication.component';

describe('OurPublicationComponent', () => {
  let component: OurPublicationComponent;
  let fixture: ComponentFixture<OurPublicationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OurPublicationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OurPublicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
