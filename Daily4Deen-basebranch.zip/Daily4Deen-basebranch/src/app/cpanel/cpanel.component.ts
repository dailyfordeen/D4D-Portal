import { Component, OnInit } from '@angular/core';
import { FileUploadService } from '../file-upload.service';
import { AuthService } from '../auth.service';
import * as moment from 'moment';
import { FirebaseService } from '../firebase.service';
import { NotificationsService, NotificationType } from 'angular2-notifications';
import { AngularFireStorage } from '@angular/fire/storage';
import { finalize } from 'rxjs/operators';
import { LOADER_SHOW, LOADER_HIDE } from '../constants/AppConstants';
import * as _ from "lodash";
@Component({
  selector: 'app-cpanel',
  templateUrl: './cpanel.component.html',
  styleUrls: ['./cpanel.component.scss']
})
export class CpanelComponent implements OnInit {
  basePath: any;
  lessonPreviewImage: any;
  lessonPDFUrl: any;
  lessonList: any[];
  userList: any[];
  errorList: any[];
  menuList: { id:any,menuName: any; menuId: any; lessonCount: any }[];
  associatedLesson: any;
  /**
   * 
   * @param fileUploadService 
   * @param fireBaseService 
   * @param authService 
   */
  constructor(private fileUploadService: FileUploadService, private fireBaseService: FirebaseService,
    private authService: AuthService, private _notifications: NotificationsService, private storage: AngularFireStorage, private storage2: AngularFireStorage) { }
  course: string;
  lessonName: string;
  lessonDesc: string;
  lessonImg: string;
  lessonPDF: string;
  lessonVideo: string;
  lessonQuiz: string;
  selectedFilesImg: FileList;
  selectedFilesPDF: FileList;
  catId: string;
  catname: string;

  currentFileUpload: FileUpload;
  percentage: number;
  deleteObj: any = {};
  deleteType: string;
  ngOnInit(): void {
    window.scroll(0, 0);
    this.errorList = [];
    this.clearFields();
    this.fetchLatestMenus();


  }
  getAssociatedLesson(id) {
    
  }
  fetchLatestMenus() {
    this.fireBaseService.readCustomMenu().subscribe(data => {

      this.menuList = data.map(e => {
        return {
          id: e.payload.doc.id,
          menuName: e.payload.doc.data()['menuName'],
          menuId: e.payload.doc.data()['menuId'],
          lessonCount: 0
        };
      })
      this.menuList.forEach(element => {
        this.fireBaseService.readLessonWithCategory(element['menuId']).subscribe((res: any) => {
          if (res != null) {
            if (res.length > 0) {
              this.associatedLesson = res.length;
              element['lessonCount']=this.associatedLesson; 
            }
          }
        });
      });
    });
  
  }
  setObj(item, type) {
    this.deleteObj = item;
    this.deleteType = type;
  }
  delete() {
    if (this.deleteType == "1") {
      this.fireBaseService.deleteLesson(this.deleteObj['id']);
    } else if (this.deleteType == "2") {
      this.fireBaseService.deleteUser(this.deleteObj['id']);
    }else if(this.deleteType=="3"){
      this.fireBaseService.deleteMenu(this.deleteObj['id']);
      this.fetchLatestMenus();
    }
    this._notifications.create('Success!', 'Deleted Successfully ..', NotificationType.Success, {
      timeOut: 500,
    })
    
  }
  selectFile(event, type): void {
    if (type == 0) {
      this.selectedFilesImg = event.target.files;
    } else if (type == 1) {
      this.selectedFilesPDF = event.target.files;
    }

  }
  clearFields() {
    this.course = '';
    this.lessonName = '';
    this.lessonDesc = '';
    this.lessonImg = '';
    this.lessonPDF = '';
    this.lessonVideo = '';
    this.lessonQuiz = '';
    this.catId = '';
    this.catname = '';
    this.catId = '';
    this.catname = '';
    this.errorList = [];
    this.fetchLatestMenus();
  }
  saveLesson() {
    this.validateLesson();



  }
  saveCategory() {
    this.errorList = [];
    if (_.isEmpty(this.catId)) {
      this.errorList.push('Please select the Course Category Id');
    }
    if (_.isEmpty(this.catname)) {
      this.errorList.push('Please provide the Course Category name');
    }
    if (this.errorList.length == 0) {
      let categoryObject = {};
      categoryObject['menuId'] = this.catId;
      categoryObject['menuName'] = this.catname;
      this.fireBaseService.saveCustomMenu(categoryObject).then(resp => {
        if (resp != null) {
          this.authService.showHideLoading(LOADER_HIDE);
          this._notifications.create('Success!', 'Saved Successfully ..', NotificationType.Success, {
            timeOut: 1000,
          })
          this.clearFields();
        } else {
          this.authService.showHideLoading(LOADER_HIDE);
          this._notifications.create('Error!', 'Something went wrong ..', NotificationType.Error, {
            timeOut: 1000,
          });
        }
      })
        .catch(error => {
          this.authService.showHideLoading(LOADER_HIDE);
          console.log(error);
        });
    }
  }
  validateLesson() {
    this.errorList = [];
    if (_.isEmpty(this.course)) {
      this.errorList.push('Please select the course category');
    }
    if (_.isEmpty(this.lessonName)) {
      this.errorList.push('Please provide the Lesson name');
    }
    if (_.isEmpty(this.lessonDesc)) {
      this.errorList.push('Please provide the Lesson Description');
    }
    if (_.isEmpty(this.lessonImg)) {
      this.errorList.push('Please upload lesson thumbnail');
    }
    if (_.isEmpty(this.lessonPDF)) {
      this.errorList.push('Please upload PDF');
    }
    if (_.isEmpty(this.lessonVideo)) {
      this.errorList.push('Please provide youtube EMBED url');
    }
    if (_.isEmpty(this.lessonQuiz)) {
      this.errorList.push('Please provide quiz url');
    }
    if (this.errorList.length == 0) {
      this.upload();
    }
  }
  filterCategory(event) {

    this.loadLesson(event.target.value);
  }

  getUsers() {
    this.fireBaseService.readUsers().subscribe(data => {
      console.log(data);
      this.userList = data.map(e => {
        return {
          id: e.payload.doc.id,
          username: e.payload.doc.data()['username'],
          userType: e.payload.doc.data()['userType'] == 'A' ? 'Admin' : 'Student',
          address: e.payload.doc.data()['address'],
          email: e.payload.doc.data()['email'],
          mob: e.payload.doc.data()['mob'],
          createdOn: this.ago(e.payload.doc.data()['createdOn']),


        };
      })
      console.log(this.userList);
    });
  }
  ago(time) {
    let difference = moment(moment(time)['_d']).diff(moment());
    return moment.duration(difference).humanize();
  }
  loadLesson(arg?) {
    this.fireBaseService.readLesson().subscribe(data => {

      this.lessonList = data.map(e => {
        return {
          id: e.payload.doc.id,
          course: e.payload.doc.data()['course'],
          lessonDesc: e.payload.doc.data()['lessonDesc'],
          lessonName: e.payload.doc.data()['lessonName'],
          lessonVideo: e.payload.doc.data()['lessonVideo'],
          uploadedBy: e.payload.doc.data()['uploadedBy'],
          uploadedOn: this.ago(e.payload.doc.data()['uploadedOn']),
          lessonPDF: e.payload.doc.data()['lessonPDF'],
          lessonImg: e.payload.doc.data()['lessonImg']
        };
      })
      if (arg != null) {
        this.lessonList = this.lessonList.filter(x => x.course == arg);
      }
      console.log(this.lessonList);

    });
  }
  upload(): void {
    this.authService.showHideLoading(LOADER_SHOW);
    const lessonImg = this.selectedFilesImg.item(0);
    const lessonPDF = this.selectedFilesPDF.item(0);
    const customMetadata = { app: 'Daily4DeenApp' };
    this.basePath = '/uploads';
    this.currentFileUpload = new FileUpload(lessonImg, lessonPDF);
    let filePath = `${this.basePath}/${lessonImg.name}`;
    let storageRef = this.storage.ref(filePath);
    let uploadTask = this.storage.upload(filePath, lessonImg, { customMetadata });
    let filePath2 = `${this.basePath}/${lessonPDF.name}`;
    let storageRef2 = this.storage2.ref(filePath2);
    let uploadTask2 = this.storage2.upload(filePath2, lessonPDF, { customMetadata });
    uploadTask.snapshotChanges().pipe(
      finalize(() => {
        storageRef.getDownloadURL().subscribe(downloadURL => {
          this.lessonPreviewImage = downloadURL;
          if (this.lessonPreviewImage != null) {
            uploadTask2.snapshotChanges().pipe(
              finalize(() => {
                storageRef2.getDownloadURL().subscribe(downloadURL => {
                  this.lessonPDFUrl = downloadURL;
                  if (this.lessonPDFUrl != null) {
                    this.uploadLesson();
                  }
                });
              })
            ).subscribe();
          }
        });
      })
    ).subscribe();



  }
  uploadLesson() {

    let lessonObj = {};
    lessonObj['course'] = this.course;
    lessonObj['lessonName'] = this.lessonName;
    lessonObj['lessonDesc'] = this.lessonDesc;
    lessonObj['lessonImg'] = this.lessonPreviewImage;
    lessonObj['lessonPDF'] = this.lessonPDFUrl;
    lessonObj['lessonVideo'] = "https://www.youtube.com/embed/" + this.lessonVideo.split("=")[1];
    lessonObj['lessonQuiz'] = this.lessonQuiz;
    lessonObj['uploadedBy'] = this.authService.getLoggedinUser();
    lessonObj['uploadedOn'] = moment(new Date())['_d'].toString();
    this.fireBaseService.saveLesson(lessonObj).then(resp => {
      if (resp != null) {
        this.authService.showHideLoading(LOADER_HIDE);
        this._notifications.create('Success!', 'Saved Successfully ..', NotificationType.Success, {
          timeOut: 500,
        })
        this.clearFields();
      } else {
        this.authService.showHideLoading(LOADER_HIDE);
        this._notifications.create('Error!', 'Something went wrong ..', NotificationType.Error, {
          timeOut: 500,
        });
      }
    })
      .catch(error => {
        this.authService.showHideLoading(LOADER_HIDE);
        console.log(error);
      });

  }

}
export class FileUpload {
  course: string;
  lessonName: string;
  lessonDesc: string;
  lessonImg: File;
  lessonPDF: File;
  lessonVideo: string;
  lessonQuiz: string;
  constructor(lessonImg: File, lessonPDF: File) {
    this.lessonImg = lessonImg;
    this.lessonPDF = lessonPDF;
  }
}

