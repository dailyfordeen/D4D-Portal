import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AsmaUlComponent } from './asma-ul.component';

describe('AsmaUlComponent', () => {
  let component: AsmaUlComponent;
  let fixture: ComponentFixture<AsmaUlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsmaUlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsmaUlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
