import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { BannerComponent } from './banner/banner.component';
import { FreeResourcesComponent } from './free-resources/free-resources.component';
import { IslamicStudiesComponent } from './islamic-studies/islamic-studies.component';
import { MiscComponent } from './misc/misc.component';
import { OurPublicationComponent } from './our-publication/our-publication.component';
import { QuranTbrComponent } from './quran-tbr/quran-tbr.component';
import { QuranTComponent } from './quran-t/quran-t.component';
import { KidsCourseComponent } from './kids-course/kids-course.component';
import { AuthGuardService } from './auth-guard.service';
import { CourseComponent } from './course/course.component';
import { AsmaUlComponent } from './asma-ul/asma-ul.component';
import { QuranOverviewComponent } from './quran-overview/quran-overview.component';
import { ContactComponent } from './contact/contact.component';
import { CpanelComponent } from './cpanel/cpanel.component';
import {GenericMenuComponent} from './generic-menu/generic-menu.component';
import { NewsFeedComponent } from './news-feed/news-feed.component';
import { SettingsComponent } from './settings/settings.component';

const routes: Routes = [{ path: 'login', component: LoginComponent },
{ path: 'register', component: RegisterComponent },
{ path: 'home', component: BannerComponent},
{ path: 'islamicStudies', component: IslamicStudiesComponent,canActivate : [AuthGuardService] },
{ path: 'quran-tbr', component: QuranTbrComponent,canActivate : [AuthGuardService] },
{ path: 'quran-t', component: QuranTComponent,canActivate : [AuthGuardService] },
{ path: 'kids-course', component: KidsCourseComponent,canActivate : [AuthGuardService] },
{ path: 'asma', component: AsmaUlComponent,canActivate : [AuthGuardService] },
{ path: 'quran-overview', component: QuranOverviewComponent,canActivate : [AuthGuardService] },

{ path: 'freeResource', component: FreeResourcesComponent,canActivate : [AuthGuardService] },

{ path: 'misc', component: MiscComponent,canActivate : [AuthGuardService] },
{ path: 'news', component: NewsFeedComponent,canActivate : [AuthGuardService] },
{ path: 'publication', component: OurPublicationComponent,canActivate : [AuthGuardService] },
{ path: 'settings', component: SettingsComponent,canActivate : [AuthGuardService] },
{ path: 'contact', component: ContactComponent,canActivate : [AuthGuardService] } ,
{ path: 'cpanel', component: CpanelComponent,canActivate : [AuthGuardService] } ,
{ path: 'genericMenu/:id', component: GenericMenuComponent,canActivate : [AuthGuardService] } ,
{ path: '**', redirectTo: 'login' }];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
