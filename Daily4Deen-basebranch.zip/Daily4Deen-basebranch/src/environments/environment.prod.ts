export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCsYTrS9wZlH4BQ27GNJHCQDSIszDcIZDA",
    authDomain: "daily4deen-cfcc6.firebaseapp.com",
    projectId: "daily4deen-cfcc6",
    storageBucket: "daily4deen-cfcc6.appspot.com",
    messagingSenderId: "714893899925",
    appId: "1:714893899925:web:bb07af3f8782ef3c83839c",
    measurementId: "G-TTFMJ47907"
  }
};
