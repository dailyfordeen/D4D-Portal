// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCsYTrS9wZlH4BQ27GNJHCQDSIszDcIZDA",
    authDomain: "daily4deen-cfcc6.firebaseapp.com",
    projectId: "daily4deen-cfcc6",
    storageBucket: "daily4deen-cfcc6.appspot.com",
    messagingSenderId: "714893899925",
    appId: "1:714893899925:web:bb07af3f8782ef3c83839c",
    measurementId: "G-TTFMJ47907"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
